package main

import "fmt"

func main() {
	var kartu1, kartu2, kartu3, kartu4, kartu5 string
	var b1, b2 bool
	
}