package main

import "fmt"

func main() {
	var angkanya, tebak1, tebak2, tebak3 int
	var b1, b2, b3 bool

	fmt.Scanln("i", &angkanya)
	fmt.Scanln("i", &tebak1)
	fmt.Scanln("i", &tebak2)
	fmt.Scanln("i", &tebak3)

	b1 = angkanya==tebak3
	b2 = tebak1==angkanya[0] || tebak1==angkanya[1] || tebak1==angkanya[2] || tebak1==angkanya[3]
	b3 = tebak2==angkanya[0] + angkanya[1] || tebak2==angkanya[2] + angkanya[3] || tebak2==angkanya[1] + angkanya[2]

	fmt.Printf("%b", &b1)
	fmt.Printf("%b", &b2)
	fmt.Printf("%b", &b3)
}